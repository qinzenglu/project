#include "StdAfx.h"
#include "CPPCSV.h"

int main(int argc, char* argv[])
{
	if(argc!=4){
		cout<<"Usage: XML.exe XRATE.csv input.xml output.csv ! " <<endl;
		return false;
	}

	string str = argv[1];
	if(str.substr(str.length()-3,3)!="csv"){
		cout<<"Fisrt input argument is .csv file ! " <<endl;
		cout<<"Usage: XML.exe XRATE.csv input.xml output.csv ! " <<endl;
		return false;
	}

	str = argv[2];
	if(str.substr(str.length()-3,3)!="xml"){
		cout<<"Second input argument is .xml file ! " <<endl;
		cout<<"Usage: XML.exe XRATE.csv input.xml output.csv ! " <<endl;
		return false;
	}

	str = argv[3];
	if(str.substr(str.length()-3,3)!="csv"){
		cout<<"Output file is .csv file ! " <<endl;
		cout<<"Usage: XML.exe XRATE.csv input.xml output.csv ! " <<endl;
		return false;
	}

    // Load xrate from csv file
    CPPCSV cppcsv;
    cppcsv.LoadCSV(argv[1]);

   //Build ratemap
	if(!cppcsv.ParstRate()){
		cout<<"XRATE is not valid in input csv file ! " <<endl;
		cout<<"Usage: XML.exe XRATE.csv input.xml output.csv ! " <<endl;
		return false;
	}

	//Parse xml file
	//Exception handling in member function
	if(!cppcsv.ParsXML(argv[2])){
		return false;
	}

   //Generate csv report by loopings using TRADEID as row and ASOFDATE as column
	if(cppcsv.GenReport(argv[3]))
		cout<<"Succeful! Report in "<<argv[3]<<"."<<endl;
	else
		cout<<"Fail to Generate report"<<endl;

	return true;
}