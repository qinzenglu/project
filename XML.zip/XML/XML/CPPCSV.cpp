#include "StdAfx.h"
#include "CPPCSV.h"



CPPCSV::CPPCSV(const char* path)
{
    LoadCSV(path);
}

bool CPPCSV::LoadCSV(const char* path)
{
    FILE* pfile = fopen(path, "r");
    if (pfile)
    {
        fseek(pfile,0,SEEK_END);
        u32 dwsize = ftell(pfile);
        rewind(pfile);

        char* filebuffer = new char[dwsize];
        fread(filebuffer, 1, dwsize, pfile);

        std::map<u32, std::string> StringMap;
        char* pBegin = filebuffer;
        char* pEnd = strchr(filebuffer, '\n');
        u32 uiIndex = 1;
        while (pEnd != NULL)
        {
            std::string strbuff;
            strbuff.insert(0, pBegin, pEnd-pBegin);
            if (!strbuff.empty())
            {
                StringMap[uiIndex] = strbuff;
            }
            pBegin = pEnd + 1;
            pEnd = strchr(pEnd + 1, '\n');
            ++uiIndex;
        }
        delete[] filebuffer;

        std::map<u32, std::string>::iterator iter = StringMap.begin();
        for (; iter != StringMap.end(); ++iter)
        {
            std::vector<std::string> StringVec;
            std::map<u32, std::string> l_StringMap;
            StringParser::GetParamFromString(iter->second, StringVec);
            for (int i = 0; i < StringVec.size(); ++i)
            {
                l_StringMap[i+1] = StringVec.at(i);
            }
            m_StringKeyMap[iter->first] = l_StringMap;
        }
        fclose(pfile);
        m_CSVName = path;
        return true;
    }

    return false;
}


bool CPPCSV::GetInt(u32 uiLine, u32 uiRow, int& iValue)
{
    std::string* pKey = GetString(uiLine, uiRow);
    if (pKey)
    {
        iValue = atoi(pKey->c_str());
        return true;
    }
    else
    {
        return false;
    }
}

bool CPPCSV::Getdouble(u32 uiLine, u32 uiRow, double& fValue)
{
    std::string* pKey = GetString(uiLine, uiRow);
    if (pKey)
    {
        fValue = atof(pKey->c_str());
        return true;
    }
    else
    {
        return false;
    }
}

std::string* CPPCSV::GetString(u32 uiLine, u32 uiRow)
{
    std::map<u32, std::map<u32, std::string> >::iterator iterLine = m_StringKeyMap.find(uiLine);
    if (iterLine != m_StringKeyMap.end())
    {
        std::map<u32, std::string>& rStringMap = iterLine->second;
        std::map<u32, std::string>::iterator iterRow = rStringMap.find(uiRow);
        if (iterRow != rStringMap.end())
        {
            return &iterRow->second;
        }
        else
        {
            return NULL;
        }
    }
    else
    {
        return NULL;
    }
}

bool CPPCSV::SetNumber(u32 uiLine, u32 uiRow, int iValue)
{
    std::string* pKey = GetString(uiLine, uiRow);
    if (pKey)
    {
        char buffer[100];
        memset(buffer, 0, sizeof(buffer));
        sprintf(buffer, "%d", iValue);
        pKey->clear();
        *pKey = buffer;
        return true;
    }
    else
    {
        return false;
    }
}

bool CPPCSV::SetNumber(u32 uiLine, u32 uiRow, double fValue)
{
    std::string* pKey = GetString(uiLine, uiRow);
    if (pKey)
    {
        char buffer[100];
        memset(buffer, 0, sizeof(buffer));
        sprintf(buffer, "%d", fValue);
        pKey->clear();
        *pKey = buffer;
        return true;
    }
    else
    {
        return false;
    }
}

bool CPPCSV::SetString(u32 uiLine, u32 uiRow, const char* pStr)
{
    std::string* pKey = GetString(uiLine, uiRow);
    if (pKey)
    {
        pKey->clear();
        *pKey = pStr;
        return true;
    }
    else
    {
        return false;
    }
}

bool CPPCSV::SaveCSV(const char* path)
{
    if (path != NULL)
    {
        m_CSVName = path;
    }

    FILE* pfile = fopen(m_CSVName.c_str(), "w");
    if (pfile)
    {
        std::map<u32, std::map<u32, std::string> >::iterator iter = m_StringKeyMap.begin();
        for (; iter != m_StringKeyMap.end(); ++iter)
        {
            std::map<u32, std::string>& rStringMap = iter->second;
            std::map<u32, std::string>::iterator it = rStringMap.begin();
            for (; it != rStringMap.end(); ++it)
            {
                std::string key = it->second;
                key += ',';
                fwrite(key.c_str(), 1, key.size(), pfile);
            }
            char Delim = '\n';
            fwrite(&Delim, 1, 1, pfile);
        }
        fclose(pfile);
    }
    else
    {
        return false;
    }

    return true;
}

void CPPCSV::ConvertToString(System::String^ str, std::string& text)
{
     char* p = (char*)(int)System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(str);
     text = p;
     System::Runtime::InteropServices::Marshal::FreeHGlobal((System::IntPtr)p);
}

bool CPPCSV::ParstRate(){
	
	int i;
	double _double = 0.0f;
	string* pString;
	bool temp;


	pString = GetString(1,1);

	if(pString==NULL || *pString!="CCY")
		return false;

	pString = GetString(1,2);

	if(pString==NULL || *pString!="XRATE")
		return false;

	for(i=2;i<=m_StringKeyMap.size();i++){
		pString = GetString(i,1);
		temp = Getdouble(i,2, _double);
		if(pString==NULL || !temp || _double<=0 ){
			return false;
		}
		rate.insert(My_Pair(*pString,_double));
	}

	return true;

}

bool CPPCSV::ParsXML(char * xmlfile){

	// Load xml 
   XmlTextReader^ reader = nullptr;
   String^ filename = System::Runtime::InteropServices::Marshal::PtrToStringAnsi((IntPtr)xmlfile);

   String^ attribute;
   Node node;
   string att;

   try
   {

      // Load the reader with the data file and ignore all white space nodes.         
      reader = gcnew XmlTextReader( filename );
      reader->WhitespaceHandling = WhitespaceHandling::None;

      // Parse the file and display each of the nodes.
      while ( reader->Read() )
      {
         switch ( reader->NodeType )
         {
			// Update Attibute Value into HashMap
            case XmlNodeType::Element:

				attribute = reader->GetAttribute( "NAME" );

				if(attribute=="TRADEID"){
					reader->Read();
					ConvertToString(reader->Value,node.tradeid);
				}
				if(attribute=="ASOFDATE"){
					reader->Read();
					ConvertToString(reader->Value,node.asofdate);
					date.insert(node.asofdate);
				}
				if(attribute=="CCY"){
					reader->Read();
					ConvertToString(reader->Value,node.ccy);
				}
				if(attribute=="SECURITY_ID"){
					reader->Read();
					ConvertToString(reader->Value,node.security_id);
				}
				if(attribute=="MARKET_VALUE"){
					reader->Read();
					ConvertToString(reader->Value,att);
					node.market_value = atof(att.c_str());
				}

               break;

            case XmlNodeType::Text:
               //Console::Write( reader->Value );
               break;

            case XmlNodeType::CDATA:
               //Console::Write( "<![CDATA[{0}]]>", reader->Value );
               break;

            case XmlNodeType::ProcessingInstruction:
               //Console::Write( "<?{0} {1}?>", reader->Name, reader->Value );
               break;

            case XmlNodeType::Comment:
               //Console::Write( "<!--{0}-->", reader->Value );
               break;

            case XmlNodeType::XmlDeclaration:
               //Console::Write( "<?xml version='1.0'?>" );
               break;

            case XmlNodeType::Document:
               break;

            case XmlNodeType::DocumentType:
               //Console::Write( "<!DOCTYPE {0} [{1}]", reader->Name, reader->Value );
               break;

            case XmlNodeType::EntityReference:
               //Console::Write( reader->Name );
               break;

            case XmlNodeType::EndElement:
               //Insert one node into map
				if(reader->Name=="ROW" && node.market_value>0){
					map<string, std::map<string, double> >::iterator iterLine = XMLMap.find(node.tradeid);
					if (iterLine != XMLMap.end())
					{
						map<string, double>& rStringMap = iterLine->second;
						map<string, double>::iterator iterRow = rStringMap.find(node.asofdate);
						if (iterRow != rStringMap.end())
						{
							iterRow->second += node.market_value/rate[node.ccy];
						}
						else
						{
							// remember to convert currency
							rStringMap.insert(My_Pair(node.asofdate,node.market_value/rate[node.ccy]));
							XMLMap.insert(Map_Pair(node.tradeid,rStringMap));
						}
					}
					else
					{	// remember to convert currency
						map<string, double> rStringMap;
						rStringMap.insert(My_Pair(node.asofdate,node.market_value/rate[node.ccy]));
						XMLMap.insert(Map_Pair(node.tradeid,rStringMap));
					}
				}
               break;
         }
      }
	  return true;
   }
   catch(...){
		cout<<"Input xml is not a valid  xml file ! " <<endl;
		cout<<"Usage: XML.exe XRATE.csv input.xml output.csv ! " <<endl;
		return false;
   }
   finally
   {
      if ( reader != nullptr )
            reader->Close();
   }
   return false;
}

bool CPPCSV::GenReport(char * output){

	ofstream file(output);
	if(!file) return false;

	file<<"TRADEID,";

    set<string>::iterator sp;
    for(sp=date.begin();sp!=date.end();sp++)
	   file<<*sp<<",";

	file<<"MEAN,STANDARD DEVIATION"<<endl;

	map<string, std::map<string, double> >::iterator iterLine;

	double sum;
	int count;
	double mean;
	double pre_mean;
	double value;

	for(iterLine=XMLMap.begin();iterLine!=XMLMap.end();iterLine++){
	   file<<iterLine->first<<",";

	   sum = 0;
	   count = 0;
	   mean = 0;
	   pre_mean = 0;

	   for(sp=date.begin();sp!=date.end();sp++){
		   value = XMLMap[iterLine->first][*sp];
		   file<<value<<",";
		   if(value!=0){
			   // One pass to calculate standard deviation
			   count++;
			   mean = pre_mean + (value - pre_mean)/count;
			   sum += (value-pre_mean)*(value-mean);
			   pre_mean=mean;
		   }
	   }
	   file<<mean<<","<<sqrt(sum/count)<<","<<endl;
	}
	file.close();

	return true;
}