#pragma once
#include "StringParser.h"
#include <stdlib.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <cstring>
#include <string>
#include <fstream>
#include <stdexcept>
#include <sstream>


#using <System.Xml.dll>
using namespace std;
using namespace System;
using namespace System::IO;
using namespace System::Xml;

using namespace std;

typedef pair<string, double> My_Pair;
typedef pair<string, map<string, double>> Map_Pair;

// Struct to store each trade
struct Node {
    string tradeid;
	string asofdate;
	string ccy;
	string security_id;
	double market_value;

};

class CPPCSV
{

public:
    CPPCSV(){};
    ~CPPCSV(){};
    CPPCSV(const char* path);


    bool LoadCSV(const char* path);
    bool SaveCSV(const char* path = NULL);

    bool GetInt(u32 uiLine, u32 uiRow, int& iValue);
    bool Getdouble(u32 uiLine, u32 uiRow, double& fValue);
    std::string* GetString(u32 uiLine, u32 uiRow);
    bool SetNumber(u32 uiLine, u32 uiRow, int iValue);
    bool SetNumber(u32 uiLine, u32 uiRow, double fValue);
    bool SetString(u32 uiLine, u32 uiRow, const char* pStr);
    std::map<u32, std::map<u32, std::string> >& GetCSVMap(){return m_StringKeyMap;}

	//Parse xrate
	bool ParstRate();

	//Parse xml file
	bool ParsXML(char * xmlfile);

	//utility function
	void ConvertToString(System::String^ str, std::string& text);

	//Generate Report
	bool GenReport(char * output);

protected:
    std::string m_CSVName;
	// Data structure to store csv file into memory with row num and col num as key
    std::map<u32, std::map<u32, std::string> > m_StringKeyMap;

	//Map to store xrate with key value as CCY
	map<string, double> rate;

	//Map to store xml data with TRADEID and ASOFDATE as key value
	map<string, std::map<string, double> > XMLMap;

	//Set to store unique ASOFDATE for all TRADEID
	set<string> date;

};

